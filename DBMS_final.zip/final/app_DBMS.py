from flask import Flask, jsonify, render_template, request, redirect, flash
import sqlite3
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)


@app.route('/')
def hello():    
    return index();

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/search_table')
def search_table():
    return render_template('search_table.html')

@app.route('/show_table', methods=['POST'])
def show_table():
    if request.method == 'POST':
           table_name = request.form.get('table_name')
           conn = sqlite3.connect('./DBMSproject')
           cursor = conn.cursor()
           sql_result = cursor.execute( 'SELECT * FROM {}'.format(table_name))
           final_result = sql_result.fetchall()
           cursor.close()
           conn.close()
           return jsonify(final_result)


@app.route('/search_value')
def search_result():
    return render_template('search_value.html')

@app.route('/show_result', methods=['POST'])
def show_result():
    if request.method == 'POST':
         table_name = request.form.get('table_name')
         if table_name == 'Bproject' or table_name == 'Bid' :
           value_name = request.form.get('value_name')
           conn = sqlite3.connect('./DBMSproject')
           cursor = conn.cursor()
           sql_result = cursor.execute( 'SELECT * FROM {} where BID={}'.format(table_name,value_name))
           final_result = sql_result.fetchall()

           cursor.close()
           conn.close()
           if final_result:
                   value_msg="成功"
           else:
                   value_msg="找不到任何資料"
           result = {
                   "msg":value_msg,
                   "result":final_result
           }
           return jsonify(result)

         elif table_name == 'Bidproject':
           value_name = request.form.get('value_name')
           com_name = request.form.get('com_name')
           conn = sqlite3.connect('./DBMSproject')
           cursor = conn.cursor()
           if value_name and com_name :
              sql_result = cursor.execute( 'SELECT * FROM Bidproject where BID={} and CID={}'.format(value_name,com_name))
           else:
              sql_result = cursor.execute( 'SELECT * FROM Bidproject where  CID={}'.format(com_name))
           
           final_result = sql_result.fetchall()

           cursor.close()
           conn.close()
           if final_result:
                   value_msg="成功"
           else :
                   value_msg="找不到任何資料"
           result = {
                   "msg":value_msg,
                   "result":final_result
           }
           return jsonify(result)

    
@app.route('/data')
def data():
    return render_template('data.html')

@app.route('/modify', methods=['POST'])
def modify():
    if request.method == 'POST':
        table_name = request.form.get('table_name')
        operation = request.form.get('operation')
        conn = sqlite3.connect('./DBMSproject',timeout=10)

        cursor = conn.cursor()
        if operation == 'INSERT':
            if table_name == 'Bproject':
                BID = request.form.get('pro_BID')
                CID = request.form.get('pro_CID')
                BDATE = request.form.get('pro_BDATE')
                BCOST = request.form.get('pro_BCOST')
                sql = 'INSERT INTO Bproject(BID, CID, BDATE, BCOST) VALUES (?,?,?,?);'
                cursor.execute(sql,(BID,CID,BDATE, BCOST,))
            elif table_name == 'Bidproject':
                BID = request.form.get('pro_BID')
                CID = request.form.get('pro_CID')
                DATE = request.form.get('pro_BDATE')
                COST = request.form.get('pro_BCOST')
                sql = 'INSERT INTO Bidproject(BID, CID, DATE, COST) VALUES (?,?,?,?);'
                cursor.execute(sql,(BID,CID,DATE, COST,))
            elif table_name == 'Bid':
                BID = request.form.get('pro_BID')
                DATE = request.form.get('pro_BDATE')
                sql = 'INSERT INTO Bid(BID, DATE) VALUES (?,?);'
                cursor.execute(sql,(BID,DATE,))

                
        elif operation == 'DELETE':
            if table_name == 'Bproject':
                BID = request.form.get('pro_BID')
                CID = request.form.get('pro_CID')
                BDATE = request.form.get('pro_BDATE')
                BCOST = request.form.get('pro_BCOST')                
                sql = 'DELETE FROM Bproject WHERE BID=? and CID=? and BDATE=? and BCOST=?;'
                cursor.execute(sql, (BID, CID, BDATE, BCOST,))
            elif table_name == 'Bidproject':
                BID = request.form.get('pro_BID')
                CID = request.form.get('pro_CID')
                DATE = request.form.get('pro_BDATE')
                COST = request.form.get('pro_BCOST')                
                sql = 'DELETE FROM Bidproject WHERE BID=? and CID=? and DATE=? and COST=?;'
                cursor.execute(sql, (BID, CID, DATE, COST,))
            if table_name == 'Bid':
                BID = request.form.get('pro_BID')
                DATE = request.form.get('pro_BDATE')         
                sql = 'DELETE FROM Bid WHERE BID=?  and DATE=? ;'
                cursor.execute(sql, (BID,DATE,))

        cursor.close()
        conn.commit()
        conn.close()
    return redirect('/data')
    

@app.route('/data_update')
def data_update():
    return render_template('data_update.html')

@app.route('/update', methods=['POST'])
def update():
    
    if request.method == 'POST':
        table_name = request.form.get('table_name')
        operation = request.form.get('operation')
        conn = sqlite3.connect('./DBMSproject',timeout=10)
        cursor = conn.cursor()
        
        if table_name == 'Bproject':
            BID = request.form.get('pro_BID')
            CID = request.form.get('pro_CID')
            BDATE = request.form.get('pro_BDATE')
            BCOST = request.form.get('pro_BCOST')
            sql = 'UPDATE Bproject SET  CID = ?, BDATE = ?, BCOST = ? WHERE BID = ?'
            cursor.execute(sql, ( CID, BDATE, BCOST,BID))
        elif table_name == 'Bidproject':
            BID = request.form.get('pro_BID')
            CID = request.form.get('pro_CID')
            DATE = request.form.get('pro_BDATE')
            COST = request.form.get('pro_BCOST')

            sql = 'UPDATE Bidproject SET  DATE = ?, COST = ? WHERE BID=? and CID=?'
            cursor.execute(sql, ( DATE, COST,BID, CID))
        elif table_name == 'Bid':
            BID = request.form.get('pro_BID')
            DATE = request.form.get('pro_BDATE')
            sql = 'UPDATE Bid SET  DATE = ? WHERE BID = ?'
            cursor.execute(sql, (DATE,BID))


    conn.commit()
    conn.close()    
    return redirect('/data_update')

if __name__=='__main__':
    app.run(debug=True)
